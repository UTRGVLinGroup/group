import requests
from bs4 import BeautifulSoup
import json
import time 

# Replace with the actual ID from the URL (e.g., user=XXXXXXXX)
AUTHOR_ID = '3SFNLZ4AAAAJ' 
URL = f"https://scholar.google.com/citations?user={AUTHOR_ID}&hl=en"

# This 'headers' dictionary makes you look like a real browser
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

def scrape_scholar():
    all_publications = []
    start_index = 0
    page_size = 100 # Google allows up to 100 per "page" request
    
    print(f"Scraping papers starting from index {start_index}...")
        
    # Adding cstart and pagesize to the URL to get more than 20
    url = f"https://scholar.google.com/citations?user={AUTHOR_ID}&hl=en&cstart={start_index}&pagesize={page_size}"
    
    response = requests.get(url, headers=HEADERS)
    if response.status_code != 200:
        print("Blocked or failed to connect.")

    soup = BeautifulSoup(response.text, 'html.parser')
    rows = soup.find_all('tr', class_='gsc_a_tr')

    # If no more rows are found, we've reached the end of the profile
    if not rows:
        pass

    for row in rows:
        title_link = row.find('a', class_='gsc_a_at')
        details = row.find_all('div', class_='gs_gray')
        year = row.find('span', class_='gsc_a_h gsc_a_hc gs_ibl')

        if title_link:
            title = title_link.text
            authors = details[0].text if len(details) > 0 else "Unknown"
            journal = details[1].text if len(details) > 1 else "Publication"
            pub_year = year.text if year and year.text.strip() else "N/A"
            
            all_publications.append({
                "title": title,
                "authors": authors,
                "year": pub_year,
                "journal": journal,
                "link": f"https://scholar.google.com/scholar?q={title.replace(' ', '+')}",
                "type": "published",
                "citation": f"{authors}. ({pub_year}). {title}. {journal}."
            })

    # Increment the starting index for the next batch
    start_index += page_size
    
    # IMPORTANT: Wait 2-3 seconds between requests so Google doesn't block your IP
    print(f"Found {len(rows)} papers in this batch. Waiting a moment...")
    time.sleep(2)

    # Save everything to the JSON file
    with open('publications.json', 'w', encoding='utf-8') as f:
        json.dump(all_publications, f, indent=4)

    print(f"DONE! Total papers saved: {len(all_publications)}")

if __name__ == "__main__":
    scrape_scholar()